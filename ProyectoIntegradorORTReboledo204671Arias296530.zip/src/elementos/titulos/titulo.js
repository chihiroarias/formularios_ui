export default function Titulo(props) {
  const { texto } = props;

  return (
    <div>
      <h1>{texto}</h1>
    </div>
  );
}
