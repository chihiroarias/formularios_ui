export default function Subtitulo(props) {
  const { texto } = props;

  return (
    <div>
      <h2>{texto}</h2>
    </div>
  );
}
