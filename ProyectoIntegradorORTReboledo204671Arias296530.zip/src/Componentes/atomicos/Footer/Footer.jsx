import "./footer.css";

export default function Footer() {
  return <footer className="pb-6"> <strong>Bruno Arias</strong> - <strong>Guillermo Reboledo</strong></footer>;
}
