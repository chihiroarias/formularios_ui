export const optionsForSelect = [
    { value: "0", name: "" },
    { value: "1", name: "Crear mi propio Select" },
    { value: "2", name: "Select precargado" },
    { value: "3", name: "Select anidado" },
    { value: "4", name: "Selects existentes" },
  ];