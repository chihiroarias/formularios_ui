export const formDescription = {
	//Estos tamañaos equivalen a h1,h2,etc...
	1: '2em',
	2: '1.5em',
	3: '1.3em',
	4: '1em',
	5: '0.8em',
	6: '0.7em',
};